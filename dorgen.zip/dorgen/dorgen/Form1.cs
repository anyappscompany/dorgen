﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Net;
using System.Web;
using System.Text.RegularExpressions;

namespace dorgen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = kwfilename = AppDomain.CurrentDomain.BaseDirectory + "kwlist.txt";            
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            if (backgroundWorker1.WorkerSupportsCancellation == true)
            {
                StartButton.Enabled = true;
                backgroundWorker1.CancelAsync();
                StopButton.Enabled = false;
                statuspr = true;
            }
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            StartButton.Enabled = false;
            StopButton.Enabled = true;
            progressBar1.Value = 0;
            progressBar1.Value = 0;
            backgroundWorker1.RunWorkerAsync();
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = kwfilename = ofd.FileName;
            }
        }

        private static string kwfilename;
        private static int totalkw;
        private static bool statuspr = false;
        public struct objavka
        {
            public string title;
            public string bodyt;
            public string domain;
        }
        public struct snipet
        {
            public string title;
            public string bodyt;            
        }
        public List<objavka> objavki = new List<objavka>();
        public List<snipet> snipeti = new List<snipet>();
        public string textblock = string.Empty;
        public static string prevtext;
        public static string nexttext;
        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            string[] lines = File.ReadLines(kwfilename).ToArray();
            totalkw = lines.Length;
            this.Invoke((MethodInvoker)delegate()
            {
                this.progressBar1.Maximum = lines.Length;
                this.progressBar1.Step = 1;
            });
            
            BackgroundWorker worker = sender as BackgroundWorker;

            string titlename = "";
            
            string DESCRIPTION = "";
            this.Invoke((MethodInvoker)delegate()
            {
                titlename = SiteTitle.Text;
                
                DESCRIPTION = Description.Text;
            });

            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename);
            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\images");

            string sourcePath = AppDomain.CurrentDomain.BaseDirectory + "templates\\images";
            string targetPath = AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\images";


            try
            {
                CopyDir(sourcePath, targetPath);
            }
            catch (Exception ex) { }

            Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\banners");
            System.IO.File.Create(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\banners\\BOTTOMBANNER.php");
            System.IO.File.Create(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\banners\\CONTENTBANNER.php");
            System.IO.File.Create(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\banners\\RIGHTSIDEBARBANNER.php");

            string sitemapgen = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "templates\\sitemapgen.php");
            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\sitemapgen.php", sitemapgen);

            string indexfile = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "templates\\index.php");
            File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\index.php", indexfile.Replace("[SITETITLE]", titlename).Replace("[DESCRIPTION]", DESCRIPTION));

            for (int i = 0; i <= lines.Length-1; i++)
            {
                
                string kwslovo = lines[i];

                if (kwslovo.Length > 100)
                {
                    kwslovo = kwslovo.Substring(0, 100);
                }

                if ((worker.CancellationPending == true))
                {
                    e.Cancel = true;
                    break;
                }
                else
                {
                    this.Invoke((MethodInvoker)delegate()
                    {
                        textBox2.Text = UppercaseFirst(kwslovo); 
                        button1.Enabled = true;
                    });

                    if (checkBox4.Checked != true)
                    {
                        while (!statuspr) { }
                    }
                    this.Invoke((MethodInvoker)delegate()
                    {
                        kwslovo = textBox2.Text;
                    });
                    string text = string.Empty;
                    // Работа
                    if (checkBox1.Checked == true)
                    {
                        try
                        {
                            textblock = GetText(kwslovo);
                            textblock = GetPerevod(textblock);
                            textblock = videlenie(textblock);
                            textblock = textblock.Replace("105105105", "");
                        }
                        catch(Exception ex)
                        {
                            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Ошибка(парсинг текста и перевод) " + ex.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    });
                        }
                        //парсинг страниц и перевод
                    }
                    if (checkBox2.Checked == true)
                    {
                        objavki.Clear();
                        try
                        {
                            objavki = GetObjavki(kwslovo);
                        }
                        catch(Exception ex)
                        {
                            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Ошибка(объявки) " + ex.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    });
                        }
                        
                        // парсинг объявлений с директа
                    }
                    if (checkBox3.Checked == true)
                    {
                        
                        // парсинг снипетов
                        snipeti.Clear();
                        try
                        {
                        snipeti = GetSnipeti(kwslovo);
                        }
                        catch (Exception ex)
                        {
                            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Ошибка(снипеты) " + ex.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    });
                        }
                    }
                    System.Threading.Thread.Sleep(500);
                    worker.ReportProgress((i * 1));
                    try {
                        prevtext = lines[i-1];
                    }
                        catch(Exception ex)
                    {
                        prevtext = "";
                        }
                    try
                    {
                        nexttext = lines[i + 1];
                    }
                    catch (Exception ex)
                    {
                        nexttext = "";
                    }
                    //КОПИРОВАНИЕ ФАЙЛОВ


                    string HEADTITLE = "";
                    this.Invoke((MethodInvoker)delegate()
                    {
                        
                        HEADTITLE = textBox2.Text;
                       
                    });
                    if (HEADTITLE.Length > 100)
                    {
                        HEADTITLE = HEADTITLE.Substring(0, 100);
                    }

                    string[] array2 = new string[] { "представляет", "на сайте", "читайте на сайте", "источник", "статья на сайте", "опубликовано", "опубликовано на сайте" };

                    string pagetemplate = File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "templates\\page.htm");

                    Random random = new Random();
                    int randomNumber = random.Next(0, (array2.Length-1));

                    pagetemplate = pagetemplate.Replace("[HEADTITLE]", HEADTITLE + ": " + array2[randomNumber] + " - " + titlename);
                    pagetemplate = pagetemplate.Replace("[SITETITLE]", titlename);
                    pagetemplate = pagetemplate.Replace("[DESCRIPTION]", DESCRIPTION);

                    int countob = 0;
                    string onjavt = string.Empty;
                    foreach (objavka obj in objavki)
                    {
                        if (countob >= 4) continue;
                        countob++;
                        onjavt += "<span class=\"zagob\"><a href=\"#\">" + obj.title + "</a></span><br />";
                        onjavt += "<span class=\"textob\">" + obj.bodyt + "</span><br />";
                        onjavt += "<span class=\"urlob\">" + obj.domain + "</span><br />";
                        
                    }
                    pagetemplate = pagetemplate.Replace("[DIRECTOBJAV]", onjavt);

                    int countsn = 0;
                    string snipg = string.Empty;
                    foreach (snipet snp in snipeti)
                    {
                        if (countsn >= 4) continue;
                        countsn++;
                        snipg += "<span class=\"zagob\"><a href=\"#\">" + snp.title + "</a></span><br />";
                        snipg += "<span class=\"textob\">" + snp.bodyt + "</span><br />";
                        
                        
                    }
                    pagetemplate = pagetemplate.Replace("[SNIPETS]", snipg);

                    pagetemplate = pagetemplate.Replace("[ARCTITLE]", HEADTITLE);
                    pagetemplate = pagetemplate.Replace("[CONTENT]", textblock.Replace("105105105", ""));

                    if (prevtext.Length > 0)
                    {
                        pagetemplate = pagetemplate.Replace("[PREV]", "<a href=\"" + translit(prevtext) + ".php\">" + prevtext + "</a>");
                    }
                    else
                    {
                        pagetemplate = pagetemplate.Replace("[PREV]", "");
                    }

                    if (nexttext.Length > 0)
                    {
                        pagetemplate = pagetemplate.Replace("[NEXT]", "<a href=\"" + translit(nexttext) + ".php\">" + nexttext + "</a>");
                    }
                    else
                    {
                        pagetemplate = pagetemplate.Replace("[NEXT]", "");
                    }

                    pagetemplate = pagetemplate.Replace("[CONTENTBANNER]", "<?php include_once(\"\\banners\\CONTENTBANNER.php\"); ?>");
                    pagetemplate = pagetemplate.Replace("[BOTTOMBANNER]", "<?php include_once(\"\\banners\\BOTTOMBANNER.php\"); ?>");
                    pagetemplate = pagetemplate.Replace("[RIGHTSIDEBARBANNER]", "<?php include_once(\"\\banners\\RIGHTSIDEBARBANNER.php\"); ?>");
                    
                    File.WriteAllText(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\" + translit(HEADTITLE).Trim().ToLower() + ".php", pagetemplate);

                    using (System.IO.StreamWriter file = new System.IO.StreamWriter(AppDomain.CurrentDomain.BaseDirectory + "sites\\" + titlename + "\\pages.txt", true))
                    {
                        file.WriteLine("<title>" + UppercaseFirst(kwslovo) + "</title>");
                        file.WriteLine("<page>" + translit(kwslovo).Trim().ToLower() + ".php</page>");
                        file.WriteLine("<text>" + TruncateAtWord(textblock.Replace("<p>", "").Replace("</p>", "").Trim(), 200).Replace("105105105", "").Replace("<b>", "").Replace("</b>", "") + "</text>");
                    }
                }
                statuspr = false;
            }
            
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if ((e.Cancelled == true))
            {
                this.progressBar1.Value = 0;
                this.toolStripStatusLabel1.Text = "Отмена!";                 
            }

            else if (!(e.Error == null))
            {
                this.progressBar1.Value = 0;
                this.toolStripStatusLabel1.Text = ("Ошибка: " + e.Error.Message);
            }

            else
            {
                this.toolStripStatusLabel1.Text = "Готово!";
                this.progressBar1.Value = 0;
                StopButton.Enabled = false;
                StartButton.Enabled = true;
            }
        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.toolStripStatusLabel1.Text = ((e.ProgressPercentage + 1).ToString() + " из " + totalkw);
            progressBar1.Value = e.ProgressPercentage;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            statuspr = true;
            button1.Enabled = false;
        }

        private string UppercaseFirst(string s)
        {
            // Check for empty string.
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            // Return char and concat substring.
            return char.ToUpper(s[0]) + s.Substring(1);
        }

        public List<objavka> GetObjavki(string kw)
        {
            List<objavka> objavki2 = new List<objavka>();

            string HTML = GET("http://direct.yandex.ru/search?text=" + HttpUtility.UrlEncode(kw));
            string patternTitle = "'title':(.*)";
            string patternText = "'text':(.*)";
            string patternDomain = "'domain':(.*)";
            MatchCollection matchTitle = Regex.Matches(HTML, patternTitle, RegexOptions.Multiline);
            MatchCollection matchText = Regex.Matches(HTML, patternText, RegexOptions.Multiline);
            MatchCollection matchDomain = Regex.Matches(HTML, patternDomain, RegexOptions.Multiline);

            for (int i = 0; i < matchTitle.Count; i++)
            {
                
                string title, text, domain;
                title = matchTitle[i].Value.Replace("'title': '", "").Replace("',", "");
                text = matchText[i].Value.Replace("'text': '", "").Replace("',", "");
                domain = matchDomain[i].Value.Replace("'domain': '", "").Replace("',", "");


                objavka objava = new objavka();
                    objava.title = title;
                    objava.bodyt = text;
                    objava.domain = domain;

                    objavki2.Add(objava);
            }
            return objavki2;
        }

        private string GET(string Url)
        {
            string result = string.Empty;
            try
            {
                HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(Url);
                myRequest.Method = "GET";
                myRequest.ContentType = "text/plain;charset=utf-8";
                WebResponse myResponse = myRequest.GetResponse();
                StreamReader sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
                result = sr.ReadToEnd();
                sr.Close();
                myResponse.Close();
            }
            catch(Exception ex)
            {
                WriteLog(string.Format("Ошибка(GET) " + ex.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                Thread.Sleep(5000);
            }

            return result;
        }
        public List<snipet> GetSnipeti(string kw)
        {
            List<snipet> snipeti2 = new List<snipet>();
            string URL = string.Empty;
            this.Invoke((MethodInvoker)delegate()
            {
                if(SelectedGoogle.Checked ==true)
                {
                    URL = @"http://www.google.ru/search?site=webhp&hl=ru&q=" + HttpUtility.UrlEncode(kw) + @"&start=0&num=10";
                }
                else if(SelectedBing.Checked == true)
                {
                    URL = "http://www.bing.com/search?q=" + HttpUtility.UrlEncode(kw);
                    //
                }
            });
            string HTML = GETSnip(URL);

            

            string patternTitle = string.Empty;
            string patternText = string.Empty;

            string titlesnip = string.Empty;
            string textsnip = string.Empty; 
            this.Invoke((MethodInvoker)delegate()
            {
                //StatusBox.Text = HTML;
                if (SelectedGoogle.Checked == true)
                {
                    titlesnip = @"<h3 class=""r""><a href=""/url\?(.*?)"" target=""_blank"">(?<title>.*?)</a></h3>";
                    textsnip = @"<span class=""st"">(?<sniptext>.*?)</span>";
                }
                else if (SelectedBing.Checked == true)
                {
                    titlesnip = @"<h3><a href=""(.*?)"">(?<title>.*?)</a></h3></div>";
                    textsnip = @"(</span></span></div>|</a></li></ul>)<p>(?<sniptext>.*?)</p></div></div></li>";
                    //
                }
            });



            MatchCollection matchTitle = Regex.Matches(HTML, titlesnip, RegexOptions.Singleline);
            MatchCollection matchText = Regex.Matches(HTML, textsnip, RegexOptions.Singleline);

            
            
               
            

            for (int i = 0; i < matchTitle.Count; i++)
            {

                string title, text;
                title = matchTitle[i].Groups["title"].Value;
                text = matchText[i].Groups["sniptext"].Value;

                

                snipet snipet = new snipet();
                snipet.title = title;
                snipet.bodyt = text;


                snipeti2.Add(snipet);
            }


            return snipeti2;
        }
        public string GetText(string kw)
        {
            string textovka = GetContent(kw);
            System.IO.File.WriteAllText(@"Text.html", textovka);
            return textovka;
        }
        private string poiskovaya_sistema;
        private string GetContent(string kwwword)
        {            
            string content = "";
            
            List<string> urllist = new List<string>(); //все урлы собранные из ПС
        
        label4:
            string str = "";
            try
            {
                this.Invoke((MethodInvoker)delegate()
                {
                    if (SelectedGoogle.Checked == true)
                    {
                        poiskovaya_sistema = "Google";
                    }
                    else if (SelectedBing.Checked == true)
                    {
                        poiskovaya_sistema = "Bing";
                        //
                    }
                });

                int pagcount = 0;
                //string lang = string.Empty;
                /**************************#google*/

                if (poiskovaya_sistema == "Google")
                {
                        str = GET(@"http://www.google.ru/search?site=webhp&hl=ru&q=" + HttpUtility.UrlEncode(kwwword) + @"&start=0&num=15");
                }
                /**************************#bing*/
                else if (poiskovaya_sistema == "Bing")
                {
                    str = GET(@"http://www.bing.com/search?q=" + HttpUtility.UrlEncode(kwwword) + "&count=15");
                }
            }
            catch (Exception ex4)
            {
                this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Ошибка парсинга поисковика: " + ex4.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    });
                Thread.Sleep(15000);
                goto label4;
            }



            System.IO.File.WriteAllText(@"WriteText.html", str);
            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Получена страница поисковика: \r\n"), Color.FromArgb(/* R */ 0x00, /* G*/ 0x99, /* B */ 0x00));
                    });





            //Работа со страницей поисковика
            //string pattern3 = @"<a class=""resultDisplayUrl"" data-icl-coi=""540"" data-icl-cop=""results-main"" href=""http:\/\/cs.webcrawler.com\/ClickHandler.ashx\?ru=(?<urls>.*?)&amp;du=(.*)target=""_blank"" onclick=""gaPageViewTracking\('info.wbcrwl','nonpaid','(.*)','(.*)'\);"">(.*)</a>";
            string pattern3 = @"<h3 class=""r""><a href=""/url\?q=(?<urls>.*?)&amp;sa=U&amp";

            if (poiskovaya_sistema == "Google")
            {
                pattern3 = @"<h3 class=""r""><a href=""/url\?q=(?<urls>.*?)&amp;sa=U&amp";
            }
            else if (poiskovaya_sistema == "Yahoo")
            {
                string tmphtml = string.Empty;

                string pattern = "<h3>(?<htrs>.*?)</h3>";
                MatchCollection matchlist;
                Regex exp = new Regex(pattern, RegexOptions.IgnoreCase);
                matchlist = exp.Matches(str);
                str = string.Empty;
                if (matchlist.Count > 0)
                {
                    foreach (Match match in matchlist)
                    {
                        str += match.Groups["htrs"].Value.ToString();
                    }
                }
                str = str.Replace("%3a", ":");
                pattern3 = @"\*\*(?<urls>.*?)""target=""_blank"" lang=""ru""";
            }
            else if (poiskovaya_sistema == "Bing")
            {
                pattern3 = @"class=""sb_tlst""><h3><a href=""(?<urls>.*?)"" h";
            }
            else if (poiskovaya_sistema == "Webcrawler")
            {
                pattern3 = @"gaPageViewTracking\('info.wbcrwl','(.*)','(.*)','(?<urls>.*?)'\);""><a class=""resultDisplayUrl""";
            }
            else if (poiskovaya_sistema == "Hotbot")
            {
                pattern3 = @"<h3 class=""web-url resultTitle""><a href=""(?<urls>.*?)"" title=";
            }
            else if (poiskovaya_sistema == "Dogpile")
            {
                pattern3 = @"<a class=""resultTitle"" data-icl-coi=""(.*)"" data-icl-cop=""results-main"" href=""http://cs.dogpile.com/ClickHandler.ashx\?du=(?<urls>.*?)\&amp;";
            }
            else
            {
                pattern3 = @"<h3 class=""r""><a href=""/url\?q=(?<urls>.*?)&amp;sa=U&amp";
            }

            MatchCollection matchlist3;
            Regex exp3 = new Regex(pattern3, RegexOptions.IgnoreCase);
            matchlist3 = exp3.Matches(str);
            if (matchlist3.Count > 0)
            {

                foreach (Match match3 in matchlist3)
                {
                    //urllist.Add(match3.Groups["urls"].Value.Replace("http%3a%2f%2f", "http://").Replace("%2f", "/"));
                    try
                    {
                        //MessageBox.Show(match3.Groups["urls"].Value.ToString());        
                        urllist.Add(Uri.UnescapeDataString(match3.Groups["urls"].Value.ToString())); //MessageBox.Show(HttpUtility.UrlDecode(match3.Groups["urls"].Value));
                    }
                    catch
                    {

                    }
                }
            }
            //}
            string strk = "";
            foreach (string st5 in urllist)
            {
                strk += " " + st5;
            }
            //MessageBox.Show(strk);







































            bool mor = false;
            foreach (string s1 in urllist)
            {
                this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format(s1), Color.FromArgb(/* R */ 0x00, /* G*/ 0x00, /* B */ 0x99));
                    });
                string html = "";
                string titlenastr = "";
                string contp = "";
                try
                {
                    if ((s1.IndexOf("beon.ru") > -1) || (s1.IndexOf("ltalk.ru") > -1) || (s1.IndexOf("carguru.ru") > -1)) continue;
                    //html = GetPage(s1);
                    html = DownloadString(s1);

                }
                catch (Exception ex)
                {
                    this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("По адресу " + s1 + " ошибка!!!"), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    });
                    //return "";
                }

                string pattern2 = @"(<title>)(?<title>.*?)</title>";
                MatchCollection matchlist2;
                Regex exp2 = new Regex(pattern2, RegexOptions.IgnoreCase);
                matchlist2 = exp2.Matches(html);
                if (matchlist2.Count > 0)
                {
                    foreach (Match match2 in matchlist2)
                    {

                        titlenastr = match2.Groups["title"].Value;
                    }
                }
                //MessageBox.Show(titlenastr.ToString());



                html = Regex.Replace(html, "<.*?>", string.Empty);
                string pattern1 = @"(\s{4}|[.!?]\s)[А-Я](\s|[а-я]+\s|[а-я]+, )([А-Яа-яA-Z_0-9,«»—.:)(]+\s){5,}[А-Яа-я_0-9)».!?]+[.!?]+";
               
                    pattern1 = @"(\s{4}|[.!?]\s)[А-Я](\s|[а-я]+\s|[а-я]+, )([А-Яа-яA-Z_0-9,«»—.:)(]+\s){5,}[А-Яа-я_0-9)».!?]+[.!?]+";
                
                
                /*MatchCollection matchlist1;
                Regex exp1 = new Regex(pattern1, RegexOptions.IgnoreCase);
                matchlist1 = exp1.Matches(html);
                if (matchlist1.Count > 0)
                {
                    foreach (Match match1 in matchlist1)
                    {

                        titlenastr = match1.Groups["title"].Value;
                    }
                }*/
                Regex regex = new Regex(pattern1);

                Match match = regex.Match(html);
                string odintext = "";
                while (match.Success)
                {
                    //Console.WriteLine("IP-адрес был найден. Позиция {0}, значение {1}", match.Index, match.Value);
                    odintext += match.Value;
                    match = match.NextMatch();
                }
                if (odintext.IndexOf(". ") == 0)
                {
                    odintext = odintext.Remove(0, 2);
                }
                odintext = odintext.Trim();
                odintext = odintext.Replace(Environment.NewLine, "");
                odintext = System.Text.RegularExpressions.Regex.Replace(odintext, @"\s\s", " ");
                odintext = System.Text.RegularExpressions.Regex.Replace(odintext, @"\.\.", ".");
                string[] split = odintext.Split(new Char[] { '.' });
                if (split.Length > 3)
                {
                    odintext = "";
                    for (int ik = 0; ik < 3; ik++)
                    {
                        odintext += (split[ik] + ". ");
                    }
                }

                //MessageBox.Show(odintext);

                if (odintext.Length > 0)
                {
                    if (odintext.IndexOf(". ") == 0)
                    {
                        odintext = odintext.Remove(0, 2);
                    }
                    if (odintext.IndexOf("! ") == 0)
                    {
                        odintext = odintext.Remove(0, 2);
                    }
                    if (odintext.IndexOf("? ") == 0)
                    {
                        odintext = odintext.Remove(0, 2);
                    }
                    content += ("105105105" + odintext + "");

                }
                if (content.Length > 500 && !mor) { content += ""; mor = true; }
            }
            //MessageBox.Show(content);
            return content;
        }
        public string DownloadString(string address)
        {
            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("Start DownloadString " + address), Color.FromArgb(/* R */ 0x55, /* G*/ 0x55, /* B */ 0x00));
                    });
            string strWebPage = "";
            // create request
            System.Net.WebRequest objRequest = System.Net.HttpWebRequest.Create(address);
            // get response
            System.Net.HttpWebResponse objResponse;
            objRequest.Timeout = 5000;
            objResponse = (System.Net.HttpWebResponse)objRequest.GetResponse();
            // get correct charset and encoding from the server's header
            string Charset = objResponse.CharacterSet;
            Encoding encoding = Encoding.GetEncoding(Charset);

            // read response into memory stream
            MemoryStream memoryStream;
            using (Stream responseStream = objResponse.GetResponseStream())
            {
                memoryStream = new MemoryStream();

                byte[] buffer = new byte[1024];
                int byteCount;
                do
                {
                    byteCount = responseStream.Read(buffer, 0, buffer.Length);
                    memoryStream.Write(buffer, 0, byteCount);
                } while (byteCount > 0);
            }

            // set stream position to beginning
            memoryStream.Seek(0, SeekOrigin.Begin);

            StreamReader sr = new StreamReader(memoryStream, encoding);
            strWebPage = sr.ReadToEnd();

            // Check real charset meta-tag in HTML
            int CharsetStart = strWebPage.IndexOf("charset=");
            if (CharsetStart > 0)
            {
                CharsetStart += 8;
                int CharsetEnd = strWebPage.IndexOfAny(new[] { ' ', '\"', ';' }, CharsetStart);
                string RealCharset =
                       strWebPage.Substring(CharsetStart, CharsetEnd - CharsetStart);

                // real charset meta-tag in HTML differs from supplied server header???
                if (RealCharset != Charset)
                {
                    // get correct encoding
                    Encoding CorrectEncoding = Encoding.GetEncoding(RealCharset);

                    // reset stream position to beginning
                    memoryStream.Seek(0, SeekOrigin.Begin);

                    // reread response stream with the correct encoding
                    StreamReader sr2 = new StreamReader(memoryStream, CorrectEncoding);

                    strWebPage = sr2.ReadToEnd();
                    // Close and clean up the StreamReader
                    sr2.Close();
                }
            }

            // dispose the first stream reader object
            sr.Close();
            this.Invoke((MethodInvoker)delegate()
                    {
                        WriteLog(string.Format("end DownloadString " + address), Color.FromArgb(/* R */ 0x55, /* G*/ 0x55, /* B */ 0x00));
                    });
            return strWebPage;
        }
        public void WriteLog(string text, Color color)
        {
            this.Invoke((MethodInvoker)delegate()
                   {
                       if ((StatusBox.Lines.Length) > 100)
                       {
                           StatusBox.Text = string.Empty;
                       }
                       StatusBox.Select(0, 0);
                       Font font = new Font("Tahoma", 8, FontStyle.Regular);
                       StatusBox.SelectionFont = font;
                       StatusBox.SelectionColor = color;
                       StatusBox.SelectedText = text + Environment.NewLine;
                   });
        }
        public string GetPerevod(string text)
        {
            string returnedtext = string.Empty;
            string naperevod = string.Empty;
            string resultatperevoda = string.Empty;
            string[] tmpmass;
            List<string> ostaetsa = new List<string>();
            string[] lines = text.Split(new Char[] { '.' });
            for (int i = 1; i < lines.Length;i++ )
            {
                if((i%2) == 0)
                {
                    naperevod += lines[i]+"105105105     ";
                }
                else if((i%2)>0)
                {
                    ostaetsa.Add(lines[i]);
                }
                else
                { MessageBox.Show("Неизвестная ошибка"); }
            }
            naperevod = Regex.Replace(naperevod, " +", " ");
            naperevod = Regex.Replace(naperevod, " +", " ");
            naperevod = naperevod.Replace("105105105 105105105", "105105105 ");
            System.IO.File.WriteAllText(@"naperevod.html", naperevod);
            resultatperevoda = POST(@"http://seogenerator.ru/api/synonym/", "text=" + HttpUtility.UrlEncode(naperevod) + @"&base=big1&type=first&format=text");
            tmpmass = Regex.Split(resultatperevoda, "105105105");
            int count1 = 0;
            int pcount = 0;
            returnedtext = "<p>";
            foreach (string str in ostaetsa)
            {

                count1++; pcount++;
                returnedtext += str.Replace("105105105", "") + ". " + tmpmass[count1 - 1] + ". ";
                Random rand = new Random();

                if ((pcount % rand.Next(1, 6)) == 0)
                    {
                        returnedtext += "</p><p>";
                    }
                
            }
            returnedtext += "</p>";

            returnedtext = Regex.Replace(returnedtext, " +", " ");
            System.IO.File.WriteAllText(@"result.html", returnedtext);
            //MessageBox.Show(returnedtext);

                return returnedtext;
        }
        private string POST(string Url, string Data)
{
  WebRequest req = WebRequest.Create(Url);
  req.Method = "POST";
  req.Timeout = 100000;
  req.ContentType = "application/x-www-form-urlencoded";
  byte[] sentData = Encoding.GetEncoding(1251).GetBytes(Data);
  req.ContentLength = sentData.Length;
  Stream sendStream = req.GetRequestStream();
  sendStream.Write(sentData, 0, sentData.Length);
  sendStream.Close();
  WebResponse res = req.GetResponse();
  Stream ReceiveStream = res.GetResponseStream();
  StreamReader sr = new StreamReader(ReceiveStream, Encoding.UTF8);
  //Кодировка указывается в зависимости от кодировки ответа сервера
  Char[] read = new Char[256];
  int count = sr.Read(read, 0, 256);
  string Out = String.Empty;
  while (count > 0)
  {
    String str = new String(read, 0, count);
    Out += str;
    count = sr.Read(read, 0, 256);
  }
  return Out;
}
        private string GETSnip(string Url)
        {
            int poisk = 0;
            this.Invoke((MethodInvoker)delegate()
            {
                if (SelectedGoogle.Checked == true)
                {
                    poisk = 0;
                }
                else if (SelectedBing.Checked == true)
                {

                    poisk = 1;
                }
            });

            if (poisk == 0)
            {
                var webClient = new System.Net.WebClient();

                string HTML = webClient.DownloadString(Url);

                return HTML;
            }
            else
            {



                string result = string.Empty;
                try
                {
                    HttpWebRequest myRequest = (HttpWebRequest)WebRequest.Create(Url);
                    myRequest.Method = "GET";

                    WebResponse myResponse = myRequest.GetResponse();
                    StreamReader sr = new StreamReader(myResponse.GetResponseStream(), System.Text.Encoding.UTF8);
                    result = sr.ReadToEnd();
                    sr.Close();
                    myResponse.Close();
                }
                catch (Exception ex)
                {
                    WriteLog(string.Format("Ошибка(GET) " + ex.Message), Color.FromArgb(/* R */ 0x99, /* G*/ 0x00, /* B */ 0x00));
                    Thread.Sleep(5000);
                }

                return result;
            }
        }
        void CopyDir(string FromDir, string ToDir)
        {
            Directory.CreateDirectory(ToDir);
            foreach (string s1 in Directory.GetFiles(FromDir))
            {
                string s2 = ToDir + "\\" + Path.GetFileName(s1);
                File.Copy(s1, s2);
            }
            foreach (string s in Directory.GetDirectories(FromDir))
            {
                CopyDir(s, ToDir + "\\" + Path.GetFileName(s));
            }
        }
        public static string TruncateAtWord(string input, int length)
        {
            if (input == null || input.Length < length)
                return input;
            int iNextSpace = input.LastIndexOf(" ", length);
            var ret = string.Format("{0}...", input.Substring(0, (iNextSpace > 0) ? iNextSpace : length).Trim());
            return ret;
        }
        private string translit(string text)
        {
            string originalString = text;
            string replacedString;
            replacedString = originalString.Replace("Є", "YE");
            replacedString = replacedString.Replace("І", "I");
            replacedString = replacedString.Replace("Ѓ", "G");
            replacedString = replacedString.Replace("і", "i");
            replacedString = replacedString.Replace("№", "");
            replacedString = replacedString.Replace("є", "ye");
            replacedString = replacedString.Replace("ѓ", "g");
            replacedString = replacedString.Replace("А", "A");
            replacedString = replacedString.Replace("Б", "B");
            replacedString = replacedString.Replace("В", "V");
            replacedString = replacedString.Replace("Г", "G");
            replacedString = replacedString.Replace("Д", "D");
            replacedString = replacedString.Replace("Е", "E");
            replacedString = replacedString.Replace("Ё", "YO");
            replacedString = replacedString.Replace("Ж", "ZH");
            replacedString = replacedString.Replace("З", "Z");
            replacedString = replacedString.Replace("И", "I");
            replacedString = replacedString.Replace("Й", "J");
            replacedString = replacedString.Replace("К", "K");
            replacedString = replacedString.Replace("Л", "L");
            replacedString = replacedString.Replace("М", "M");
            replacedString = replacedString.Replace("Н", "N");
            replacedString = replacedString.Replace("О", "O");
            replacedString = replacedString.Replace("П", "P");
            replacedString = replacedString.Replace("Р", "R");
            replacedString = replacedString.Replace("С", "S");
            replacedString = replacedString.Replace("Т", "T");
            replacedString = replacedString.Replace("У", "U");
            replacedString = replacedString.Replace("Ф", "F");
            replacedString = replacedString.Replace("Х", "X");
            replacedString = replacedString.Replace("Ц", "C");
            replacedString = replacedString.Replace("Ч", "CH");
            replacedString = replacedString.Replace("Ш", "SH");
            replacedString = replacedString.Replace("Щ", "SHH");
            replacedString = replacedString.Replace("Ъ", "");
            replacedString = replacedString.Replace("Ы", "Y");
            replacedString = replacedString.Replace("Ь", "");
            replacedString = replacedString.Replace("Э", "E");
            replacedString = replacedString.Replace("Ю", "YU");
            replacedString = replacedString.Replace("Я", "YA");
            replacedString = replacedString.Replace("а", "a");
            replacedString = replacedString.Replace("б", "b");
            replacedString = replacedString.Replace("в", "v");
            replacedString = replacedString.Replace("г", "g");
            replacedString = replacedString.Replace("д", "d");
            replacedString = replacedString.Replace("е", "e");
            replacedString = replacedString.Replace("ё", "yo");
            replacedString = replacedString.Replace("ж", "zh");
            replacedString = replacedString.Replace("з", "z");
            replacedString = replacedString.Replace("и", "i");
            replacedString = replacedString.Replace("й", "j");
            replacedString = replacedString.Replace("к", "k");
            replacedString = replacedString.Replace("л", "l");
            replacedString = replacedString.Replace("м", "m");
            replacedString = replacedString.Replace("н", "n");
            replacedString = replacedString.Replace("о", "o");
            replacedString = replacedString.Replace("п", "p");
            replacedString = replacedString.Replace("р", "r");
            replacedString = replacedString.Replace("с", "s");
            replacedString = replacedString.Replace("т", "t");
            replacedString = replacedString.Replace("у", "u");
            replacedString = replacedString.Replace("ф", "f");
            replacedString = replacedString.Replace("х", "x");
            replacedString = replacedString.Replace("ц", "c");
            replacedString = replacedString.Replace("ч", "ch");
            replacedString = replacedString.Replace("ш", "sh");
            replacedString = replacedString.Replace("щ", "shh");
            replacedString = replacedString.Replace("ъ", "");
            replacedString = replacedString.Replace("ы", "y");
            replacedString = replacedString.Replace("ь", "");
            replacedString = replacedString.Replace("э", "e");
            replacedString = replacedString.Replace("ю", "yu");
            replacedString = replacedString.Replace("я", "ya");
            replacedString = replacedString.Replace("«", "");
            replacedString = replacedString.Replace("»", "");
            replacedString = replacedString.Replace("—", "-");
            replacedString = replacedString.Replace(" — ", "-");
            replacedString = replacedString.Replace(" - ", "-");
            replacedString = replacedString.Replace(" ", "-");
            replacedString = replacedString.Replace("...", "");
            replacedString = replacedString.Replace("..", "");
            replacedString = replacedString.Replace(":", "");
            replacedString = replacedString.Replace("\"", "");
            replacedString = replacedString.Replace(",", "");
            replacedString = replacedString.Replace("!", "");
            replacedString = replacedString.Replace(";", "");
            replacedString = replacedString.Replace("%", "");
            replacedString = replacedString.Replace("?", "");
            replacedString = replacedString.Replace("*", "");
            replacedString = replacedString.Replace("(", "");
            replacedString = replacedString.Replace(")", "");
            replacedString = replacedString.Replace("\\", "");
            replacedString = replacedString.Replace("/", "");
            replacedString = replacedString.Replace("=", "");
            replacedString = replacedString.Replace("'", "");
            replacedString = replacedString.Replace("&", "");
            replacedString = replacedString.Replace("^", "");
            replacedString = replacedString.Replace("$", "");
            replacedString = replacedString.Replace("#", "");
            replacedString = replacedString.Replace("@", "");
            replacedString = replacedString.Replace("~", "");
            replacedString = replacedString.Replace("`", "");
            replacedString = replacedString.Replace(" ", "-");


            return replacedString;
        }
        private string videlenie(string str)
        {
            string result = "";
            string[] patterns = new string[] { " [А-Яа-я]+ [А-Яа-я]+ ", " [А-Яа-я]+ [А-Яа-я]+ [А-Яа-я]+ ", " [А-Яа-я]+ [А-Яа-я]+ [А-Яа-я]+ [А-Яа-я]+ " };

            for (int i = 0; i <= 5; i++ )
            {
                Random rand = new Random();
                int rnd = rand.Next(0, 2);
                string pattern = patterns[rnd];
                var arr = Regex.Matches(str, pattern)
    .Cast<Match>()
    .Select(m => m.Value)
    .ToArray();
                string repl = arr[rand.Next(0, arr.Length - 1)].Trim();
                str = str.Replace(repl, "<b>" + repl + "</b>");
            }
            result = str;
                return result;
        }
    }
  
}
